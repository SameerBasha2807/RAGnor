"""
Entry point for Ragnar application.
 
Initializes:
- Settings
- Logging
"""
 
from ragnar.config.settings import get_settings
from ragnar.config.logging import setup_logging
 
 
def main() -> None:
    """
    Bootstrap the Ragnar system.
    """
    setup_logging()
    settings = get_settings()
 
    print(f"🚀 Starting {settings.APP_NAME} in {settings.ENV} mode")
    print(f"🔗 Ollama URL: {settings.OLLAMA_BASE_URL}")
    print(f"🧠 LLM: {settings.OLLAMA_LLM_MODEL}")
 
 
if __name__ == "__main__":
    main()
 