"""
Document loaders for Ragnar.
 
Supports:
- PDF
- Markdown
- Text
- HTML
 
All loaders return LangChain Document objects.
"""
 
from pathlib import Path
from typing import List
 
from langchain_core.documents import Document
from langchain_community.document_loaders import (
    PyPDFLoader,
    TextLoader,
    UnstructuredMarkdownLoader,
    UnstructuredHTMLLoader,
)
 
 
def load_documents(file_path: str) -> List[Document]:
    """
    Load documents based on file type.
 
    Args:
        file_path: Path to the file
 
    Returns:
        List of Document objects
    """
 
    path = Path(file_path)
 
    if not path.exists():
        raise FileNotFoundError(f"File not found: {file_path}")
 
    suffix = path.suffix.lower()
 
    if suffix == ".pdf":
        loader = PyPDFLoader(file_path)
    elif suffix in [".txt"]:
        loader = TextLoader(file_path, encoding="utf-8")
    elif suffix in [".md"]:
        loader = UnstructuredMarkdownLoader(file_path)
    elif suffix in [".html", ".htm"]:
        loader = UnstructuredHTMLLoader(file_path)
    else:
        raise ValueError(f"Unsupported file type: {suffix}")
 
    documents = loader.load()
 
    # Attach metadata
    for doc in documents:
        doc.metadata["source"] = file_path
 
    return documents
 