"""
Vector store setup using Chroma (dev).
"""
 
from langchain_community.vectorstores import Chroma
from langchain_core.documents import Document
from typing import List
 
from ragnar.config.settings import get_settings
from ragnar.ingestion.embeddings import get_embeddings
 
 
def get_vectorstore() -> Chroma:
    """
    Initialize or load Chroma DB.
 
    Returns:
        Chroma instance
    """
 
    settings = get_settings()
 
    embeddings = get_embeddings()
 
    return Chroma(
        collection_name=settings.COLLECTION_NAME,
        embedding_function=embeddings,
        persist_directory=settings.CHROMA_PERSIST_DIR,
    )
 
 
def add_documents(documents: List[Document]) -> None:
    """
    Add documents to vector store.
 
    Args:
        documents: Chunked documents
    """
 
    vectordb = get_vectorstore()
    vectordb.add_documents(documents)
    vectordb.persist()
 