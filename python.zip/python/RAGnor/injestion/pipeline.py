"""
End-to-end ingestion pipeline.
 
Flow:
Load → Split → Embed → Store
"""
 
import asyncio
from typing import List
 
from langchain_core.documents import Document
 
from ragnar.ingestion.loaders import load_documents
from ragnar.ingestion.splitter import split_documents
from ragnar.ingestion.vectorstore import add_documents
 
 
async def ingest_file(file_path: str) -> None:
    """
    Ingest a single file.
 
    Args:
        file_path: Path to file
    """
 
    # Step 1: Load
    documents: List[Document] = await asyncio.to_thread(
        load_documents, file_path
    )
 
    # Step 2: Split
    chunks: List[Document] = await asyncio.to_thread(
        split_documents, documents
    )
 
    # Step 3: Store
    await asyncio.to_thread(add_documents, chunks)
 
 
async def ingest_batch(file_paths: List[str]) -> None:
    """
    Ingest multiple files concurrently.
 
    Args:
        file_paths: List of file paths
    """
 
    tasks = [ingest_file(path) for path in file_paths]
    await asyncio.gather(*tasks)
 