"""
Text splitting logic.
 
Uses RecursiveCharacterTextSplitter for semantic chunking.
"""
 
from typing import List
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_core.documents import Document
 
 
def get_text_splitter() -> RecursiveCharacterTextSplitter:
    """
    Create a smart text splitter.
 
    Returns:
        Configured RecursiveCharacterTextSplitter
    """
 
    return RecursiveCharacterTextSplitter(
        chunk_size=800,
        chunk_overlap=150,
        separators=["\n\n", "\n", ".", " ", ""],
    )
 
 
def split_documents(documents: List[Document]) -> List[Document]:
    """
    Split documents into chunks.
 
    Args:
        documents: Raw documents
 
    Returns:
        Chunked documents
    """
 
    splitter = get_text_splitter()
    return splitter.split_documents(documents)
 