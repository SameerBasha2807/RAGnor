"""
Ollama embeddings wrapper.
"""
 
from langchain_ollama import OllamaEmbeddings
from ragnar.config.settings import get_settings
 
 
def get_embeddings() -> OllamaEmbeddings:
    """
    Initialize Ollama embeddings.
 
    Returns:
        OllamaEmbeddings instance
    """
 
    settings = get_settings()
 
    return OllamaEmbeddings(
        model=settings.OLLAMA_EMBED_MODEL,
        base_url=settings.OLLAMA_BASE_URL,
    )
 