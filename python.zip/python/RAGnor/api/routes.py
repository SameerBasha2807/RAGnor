"""
API routes.
"""
 
from fastapi import APIRouter
from fastapi.responses import StreamingResponse
 
from ragnar.api.schemas import ChatRequest
from ragnar.api.service import stream_chat
 
router = APIRouter()
 
 
@router.post("/chat/stream")
async def chat_stream(request: ChatRequest) -> StreamingResponse:
    """
    Streaming chat endpoint (SSE-like).
    """
 
    async def event_generator():
        async for chunk in stream_chat(
            user_id=request.user_id,
            query=request.query,
        ):
            yield f"data: {chunk}\n\n"
 
    return StreamingResponse(
        event_generator(),
        media_type="text/event-stream",
    )
 