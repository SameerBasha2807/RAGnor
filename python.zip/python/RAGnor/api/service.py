"""
Service layer connecting FastAPI to LangGraph.
"""
 
from typing import AsyncGenerator
 
from ragnar.agents.graph import build_graph
from ragnar.agents.state import RagnarState
 
# Initialize graph once (important for performance)
graph = build_graph()
 
 
async def stream_chat(
    user_id: str,
    query: str,
) -> AsyncGenerator[str, None]:
    """
    Stream response from LangGraph.
 
    Args:
        user_id: User identifier
        query: User query
 
    Yields:
        Response chunks
    """
 
    state: RagnarState = {
        "query": query,
        "rewritten_query": None,
        "documents": [],
        "answer": None,
        "retrieval_ok": False,
        "answer_ok": False,
        "retries": 0,
    }
 
    async for event in graph.astream(state):
        if "answer" in event and event["answer"]:
            yield event["answer"]
 