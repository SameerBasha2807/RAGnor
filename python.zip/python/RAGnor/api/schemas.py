"""
API request/response schemas.
"""
 
from pydantic import BaseModel, Field
 
 
class ChatRequest(BaseModel):
    """
    Incoming chat request.
    """
 
    user_id: str = Field(..., description="User ID")
    query: str = Field(..., description="User query")
 
 
class ChatResponse(BaseModel):
    """
    Final response (non-streaming fallback).
    """
 
    answer: str
 