"""
FastAPI entrypoint for Ragnar.
"""
 
from fastapi import FastAPI
from ragnar.api.routes import router
from ragnar.config.logging import setup_logging
from ragnar.config.settings import get_settings
 
# Initialize
setup_logging()
settings = get_settings()
 
app = FastAPI(
    title=settings.APP_NAME,
    version="1.0.0",
)
 
 
# Routes
app.include_router(router)
 
 
@app.get("/")
def health_check():
    """
    Health check endpoint.
    """
    return {"status": "ok", "app": settings.APP_NAME}
 