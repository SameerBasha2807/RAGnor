"""
Unified guardrails pipeline.
"""
 
from ragnar.guardrails.pii import PIIFilter
from ragnar.guardrails.toxicity import ToxicityFilter
 
 
class GuardrailPipeline:
    """
    Runs all safety checks.
    """
 
    def __init__(self) -> None:
        self.pii = PIIFilter()
        self.toxicity = ToxicityFilter()
 
    def input_filter(self, text: str) -> str:
        """
        Process user input.
        """
 
        text, _ = self.pii.process(text)
 
        if self.toxicity.is_toxic(text):
            raise ValueError("Toxic input detected.")
 
        return text
 
    def output_filter(self, text: str) -> str:
        """
        Process model output.
        """
 
        text, _ = self.pii.process(text)
 
        if self.toxicity.is_toxic(text):
            return "Response blocked due to unsafe content."
 
        return text
 