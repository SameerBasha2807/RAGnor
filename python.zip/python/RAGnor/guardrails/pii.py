"""
PII detection and masking.
"""
 
import re
from typing import Tuple
 
 
class PIIFilter:
    """
    Detect and mask PII in text.
    """
 
    EMAIL_PATTERN = r"[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+"
    PHONE_PATTERN = r"\b\d{10}\b"
 
    def detect(self, text: str) -> bool:
        """
        Check if PII exists.
        """
        return bool(
            re.search(self.EMAIL_PATTERN, text)
            or re.search(self.PHONE_PATTERN, text)
        )
 
    def mask(self, text: str) -> str:
        """
        Mask detected PII.
        """
        text = re.sub(self.EMAIL_PATTERN, "[EMAIL]", text)
        text = re.sub(self.PHONE_PATTERN, "[PHONE]", text)
        return text
 
    def process(self, text: str) -> Tuple[str, bool]:
        """
        Process text for PII.
 
        Returns:
            (clean_text, pii_detected)
        """
        detected = self.detect(text)
        return self.mask(text), detected
 