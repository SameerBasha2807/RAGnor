"""
Toxicity detection using local model.
"""
 
from transformers import pipeline
 
 
class ToxicityFilter:
    """
    Classifies toxic content.
    """
 
    def __init__(self) -> None:
        self.classifier = pipeline(
            "text-classification",
            model="unitary/toxic-bert",
        )
 
    def is_toxic(self, text: str) -> bool:
        """
        Detect toxicity.
        """
        result = self.classifier(text)[0]
 
        return (
            result["label"].lower() == "toxic"
            and result["score"] > 0.7
        )
 