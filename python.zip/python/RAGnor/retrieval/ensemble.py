"""
Hybrid retriever using EnsembleRetriever.
 
Combines:
- BM25 (sparse)
- Dense (vector)
"""
 
from typing import List
 
from langchain.retrievers import EnsembleRetriever
from langchain_core.documents import Document
 
from ragnar.retrieval.bm25 import build_bm25_retriever
from ragnar.retrieval.dense import get_dense_retriever
from ragnar.config.settings import get_settings
 
 
def get_ensemble_retriever(documents: List[Document]) -> EnsembleRetriever:
    """
    Create hybrid retriever.
 
    Args:
        documents: Documents for BM25
 
    Returns:
        EnsembleRetriever
    """
 
    settings = get_settings()
 
    bm25 = build_bm25_retriever(documents)
    dense = get_dense_retriever()
 
    retriever = EnsembleRetriever(
        retrievers=[bm25, dense],
        weights=[0.5, 0.5],  # Tunable
    )
 
    return retriever
 