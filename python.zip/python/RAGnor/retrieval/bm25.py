"""
BM25 sparse retriever using in-memory documents.
 
NOTE:
- This requires documents to be loaded from vectorstore
- Used as part of EnsembleRetriever
"""
 
from typing import List
from langchain_core.documents import Document
from langchain_community.retrievers import BM25Retriever
 
 
def build_bm25_retriever(documents: List[Document]) -> BM25Retriever:
    """
    Create BM25 retriever.
 
    Args:
        documents: List of documents
 
    Returns:
        BM25Retriever instance
    """
 
    retriever = BM25Retriever.from_documents(documents)
 
    # Configure number of results
    retriever.k = 5
 
    return retriever
 