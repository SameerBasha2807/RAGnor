"""
Local reranker using BGE reranker model.
 
Replaces CohereRerank (since we are fully local).
"""
 
from typing import List
from langchain_core.documents import Document
from sentence_transformers import CrossEncoder
 
from ragnar.config.settings import get_settings
 
 
class BGEReranker:
    """
    Cross-encoder reranker using BAAI/bge-reranker.
    """
 
    def __init__(self) -> None:
        settings = get_settings()
 
        # Lightweight and fast reranker
        self.model = CrossEncoder(
            "BAAI/bge-reranker-base"
        )
 
        self.top_n = settings.RERANK_TOP_N
 
    def rerank(self, query: str, documents: List[Document]) -> List[Document]:
        """
        Rerank documents based on relevance.
 
        Args:
            query: User query
            documents: Retrieved docs
 
        Returns:
            Top-N reranked documents
        """
 
        pairs = [(query, doc.page_content) for doc in documents]
 
        scores = self.model.predict(pairs)
 
        # Attach scores
        scored_docs = list(zip(documents, scores))
 
        # Sort by score descending
        ranked = sorted(
            scored_docs,
            key=lambda x: x[1],
            reverse=True
        )
 
        # Return top N
        return [doc for doc, _ in ranked[: self.top_n]]
 