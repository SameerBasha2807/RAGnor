"""
Dense retriever using Chroma + Ollama embeddings.
"""
 
from langchain_community.vectorstores import Chroma
from langchain_core.retrievers import BaseRetriever
 
from ragnar.config.settings import get_settings
from ragnar.ingestion.embeddings import get_embeddings
 
 
def get_dense_retriever() -> BaseRetriever:
    """
    Initialize dense retriever.
 
    Returns:
        Vector store retriever
    """
 
    settings = get_settings()
 
    vectordb = Chroma(
        collection_name=settings.COLLECTION_NAME,
        embedding_function=get_embeddings(),
        persist_directory=settings.CHROMA_PERSIST_DIR,
    )
 
    return vectordb.as_retriever(
        search_kwargs={"k": settings.TOP_K}
    )
 