"""
Full retrieval pipeline.
 
Flow:
Query → Hybrid Retrieval → Rerank → Return Top Docs
"""
 
import asyncio
from typing import List
 
from langchain_core.documents import Document
 
from ragnar.retrieval.ensemble import get_ensemble_retriever
from ragnar.retrieval.reranker import BGEReranker
from ragnar.ingestion.vectorstore import get_vectorstore
 
 
class RetrievalPipeline:
    """
    End-to-end retrieval system.
    """
 
    def __init__(self) -> None:
        self.reranker = BGEReranker()
 
        # Load all docs for BM25
        self.documents = self._load_all_documents()
 
        self.retriever = get_ensemble_retriever(self.documents)
 
    def _load_all_documents(self) -> List[Document]:
        """
        Load documents from Chroma.
 
        Returns:
            List of documents
        """
 
        vectordb = get_vectorstore()
 
        # WARNING: This loads entire collection into memory
        # Fine for dev, optimize later for prod
        return vectordb.get()["documents"]
 
    async def retrieve(self, query: str) -> List[Document]:
        """
        Retrieve relevant documents.
 
        Args:
            query: User query
 
        Returns:
            Reranked documents
        """
 
        # Step 1: Hybrid retrieval
        docs = await asyncio.to_thread(
            self.retriever.get_relevant_documents,
            query
        )
 
        # Step 2: Rerank
        reranked = await asyncio.to_thread(
            self.reranker.rerank,
            query,
            docs
        )
 
        return reranked
 