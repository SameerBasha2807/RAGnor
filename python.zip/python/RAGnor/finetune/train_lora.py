"""
LoRA fine-tuning script.
"""
 
from transformers import AutoModelForCausalLM, AutoTokenizer
from peft import LoraConfig, get_peft_model
from datasets import Dataset
from ragnar.finetune.dataset import build_dataset
 
 
def train():
    model_name = "meta-llama/Llama-2-7b-hf"
 
    tokenizer = AutoTokenizer.from_pretrained(model_name)
    model = AutoModelForCausalLM.from_pretrained(model_name)
 
    dataset: Dataset = build_dataset()
 
    # LoRA config
    config = LoraConfig(
        r=8,
        lora_alpha=16,
        target_modules=["q_proj", "v_proj"],
        lora_dropout=0.05,
    )
 
    model = get_peft_model(model, config)
 
    # Tokenization
    def tokenize(example):
        return tokenizer(
            example["instruction"],
            text_target=example["output"],
            truncation=True,
        )
 
    tokenized = dataset.map(tokenize)
 
    model.train()
 
    # (Trainer omitted for brevity — can add HF Trainer if needed)
 
    model.save_pretrained("lora-adapter")
 