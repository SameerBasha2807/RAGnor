"""
Prepare dataset for instruction tuning.
"""
 
from datasets import Dataset
 
 
def build_dataset():
    data = [
        {
            "instruction": "Explain hybrid search",
            "output": "Hybrid search combines BM25 and dense retrieval."
        },
        {
            "instruction": "What is Ragnar?",
            "output": "Ragnar is an agentic RAG system."
        },
    ]
 
    return Dataset.from_list(data)
 