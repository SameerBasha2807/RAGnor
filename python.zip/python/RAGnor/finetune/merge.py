"""
Merge LoRA weights into base model.
"""
 
from peft import PeftModel
from transformers import AutoModelForCausalLM
 
 
def merge():
    base = AutoModelForCausalLM.from_pretrained("meta-llama/Llama-2-7b-hf")
    model = PeftModel.from_pretrained(base, "lora-adapter")
 
    model = model.merge_and_unload()
 
    model.save_pretrained("merged-model")
 