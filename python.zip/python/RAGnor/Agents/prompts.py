"""
Centralized prompts for agent nodes.
"""
 
PLANNER_PROMPT = """
You are a query planner.
 
Rewrite the query to improve retrieval quality.
Make it:
- More specific
- Keyword rich
- Clear
 
Original Query:
{query}
 
Rewritten Query:
"""
 
GENERATOR_PROMPT = """
You are a highly accurate AI assistant.
 
Answer ONLY using the provided context.
If the answer is not in the context, say:
"I don't have enough information."
 
Context:
{context}
 
Question:
{query}
 
Answer:
"""
 
GRADER_PROMPT = """
Evaluate if the retrieved documents are relevant.
 
Query:
{query}
 
Documents:
{documents}
 
Answer YES or NO.
"""
 
CRITIC_PROMPT = """
Evaluate the answer quality.
 
Check:
- Is it grounded in context?
- Is it correct?
- Is it complete?
 
Answer:
{answer}
 
Respond with YES or NO.
"""