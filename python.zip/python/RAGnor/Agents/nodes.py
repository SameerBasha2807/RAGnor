"""
All LangGraph nodes for Ragnar.
"""
 
from typing import List
from langchain_core.documents import Document
 
from ragnar.agents.state import RagnarState
from ragnar.agents.llm import get_llm
from ragnar.agents.prompts import (
    PLANNER_PROMPT,
    GENERATOR_PROMPT,
    GRADER_PROMPT,
    CRITIC_PROMPT,
)
from ragnar.retrieval.pipeline import RetrievalPipeline
 
llm = get_llm()
retrieval_pipeline = RetrievalPipeline()
 
 
# =========================
# PLANNER NODE
# =========================
async def planner_node(state: RagnarState) -> RagnarState:
    prompt = PLANNER_PROMPT.format(query=state["query"])
 
    rewritten = await llm.ainvoke(prompt)
 
    state["rewritten_query"] = rewritten.strip()
    return state
 
 
# =========================
# RETRIEVER NODE
# =========================
async def retriever_node(state: RagnarState) -> RagnarState:
    query = state.get("rewritten_query") or state["query"]
 
    docs = await retrieval_pipeline.retrieve(query)
 
    state["documents"] = docs
    return state
 
 
# =========================
# GRADER NODE
# =========================
async def grader_node(state: RagnarState) -> RagnarState:
    docs_text = "\n\n".join([d.page_content[:500] for d in state["documents"]])
 
    prompt = GRADER_PROMPT.format(
        query=state["query"],
        documents=docs_text,
    )
 
    result = await llm.ainvoke(prompt)
 
    state["retrieval_ok"] = "yes" in result.lower()
    return state
 
 
# =========================
# GENERATOR NODE
# =========================
async def generator_node(state: RagnarState) -> RagnarState:
    context = "\n\n".join([doc.page_content for doc in state["documents"]])
 
    prompt = GENERATOR_PROMPT.format(
        context=context,
        query=state["query"],
    )
 
    answer = await llm.ainvoke(prompt)
 
    state["answer"] = answer.strip()
    return state
 
 
# =========================
# CRITIC NODE
# =========================
async def critic_node(state: RagnarState) -> RagnarState:
    prompt = CRITIC_PROMPT.format(answer=state["answer"])
 
    result = await llm.ainvoke(prompt)
 
    state["answer_ok"] = "yes" in result.lower()
    return state
 
 
# =========================
# QUERY REWRITE (RETRY)
# =========================
async def rewrite_node(state: RagnarState) -> RagnarState:
    state["retries"] += 1
 
    # fallback rewrite
    state["rewritten_query"] = f"{state['query']} detailed explanation"
 
    return state