"""
LangGraph workflow for Ragnar Agentic RAG.
"""
 
from langgraph.graph import StateGraph, END
 
from ragnar.agents.state import RagnarState
from ragnar.agents.nodes import (
    planner_node,
    retriever_node,
    grader_node,
    generator_node,
    critic_node,
    rewrite_node,
)
 
 
def build_graph():
    """
    Build LangGraph workflow.
    """
 
    graph = StateGraph(RagnarState)
 
    # Nodes
    graph.add_node("planner", planner_node)
    graph.add_node("retriever", retriever_node)
    graph.add_node("grader", grader_node)
    graph.add_node("generator", generator_node)
    graph.add_node("critic", critic_node)
    graph.add_node("rewrite", rewrite_node)
 
    # Flow
    graph.set_entry_point("planner")
 
    graph.add_edge("planner", "retriever")
    graph.add_edge("retriever", "grader")
 
    # Conditional: retrieval quality
    graph.add_conditional_edges(
        "grader",
        lambda state: "good" if state["retrieval_ok"] else "bad",
        {
            "good": "generator",
            "bad": "rewrite",
        },
    )
 
    graph.add_edge("rewrite", "retriever")
 
    graph.add_edge("generator", "critic")
 
    # Conditional: answer quality
    graph.add_conditional_edges(
        "critic",
        lambda state: "good" if state["answer_ok"] else "bad",
        {
            "good": END,
            "bad": "generator",
        },
    )
 
    return graph.compile()
 