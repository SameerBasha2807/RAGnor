"""
Ollama LLM wrapper.
"""
 
from langchain_ollama import Ollama
from ragnar.config.settings import get_settings
 
 
def get_llm() -> Ollama:
    """
    Initialize Ollama LLM.
    """
 
    settings = get_settings()
 
    return Ollama(
        model=settings.OLLAMA_LLM_MODEL,
        base_url=settings.OLLAMA_BASE_URL,
        temperature=0.2,  # lower = more factual
    )
 