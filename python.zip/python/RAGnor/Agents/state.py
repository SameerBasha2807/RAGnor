"""
LangGraph state definition for Ragnar.
"""
 
from typing import List, TypedDict, Optional
from langchain_core.documents import Document
 
 
class RagnarState(TypedDict):
    """
    Shared state across all nodes in the graph.
    """
 
    query: str
    rewritten_query: Optional[str]
 
    documents: List[Document]
 
    answer: Optional[str]
 
    # Evaluation flags
    retrieval_ok: bool
    answer_ok: bool
 
    # Iteration control
    retries: int
 