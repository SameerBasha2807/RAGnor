"""
Short-term memory using LangGraph MemorySaver.
"""
 
from langgraph.checkpoint.memory import MemorySaver
 
 
def get_short_term_memory() -> MemorySaver:
    """
    Initialize in-memory checkpointing.
 
    Returns:
        MemorySaver instance
    """
 
    return MemorySaver()
 