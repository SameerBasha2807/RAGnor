"""
Long-term memory using PostgresSaver.
"""
 
from langgraph.checkpoint.postgres import PostgresSaver
from sqlalchemy.ext.asyncio import create_async_engine
 
from ragnar.config.settings import get_settings
 
 
def get_postgres_memory() -> PostgresSaver:
    """
    Initialize Postgres-backed memory.
 
    Returns:
        PostgresSaver instance
    """
 
    settings = get_settings()
 
    engine = create_async_engine(settings.POSTGRES_URI)
 
    return PostgresSaver(engine)