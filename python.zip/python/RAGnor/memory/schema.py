"""
Pydantic models for memory.
"""
 
from pydantic import BaseModel, Field
from datetime import datetime
 
 
class MemoryRecord(BaseModel):
    """
    Represents a stored interaction.
    """
 
    user_id: str = Field(..., description="User identifier")
    query: str
    answer: str
    created_at: datetime = Field(default_factory=datetime.utcnow)
 