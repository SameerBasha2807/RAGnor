"""
Unified memory manager.
 
Handles:
- Writing to long-term memory
- Fetching past conversations
"""
 
from typing import List
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import text
 
from ragnar.memory.schema import MemoryRecord
from ragnar.config.settings import get_settings
from sqlalchemy.ext.asyncio import create_async_engine
 
 
class MemoryManager:
    """
    Handles long-term memory operations.
    """
 
    def __init__(self) -> None:
        settings = get_settings()
        self.engine = create_async_engine(settings.POSTGRES_URI)
 
    async def save_interaction(
        self,
        user_id: str,
        query: str,
        answer: str,
    ) -> None:
        """
        Save interaction to Postgres.
        """
 
        async with self.engine.begin() as conn:
            await conn.execute(
                text(
                    """
                    CREATE TABLE IF NOT EXISTS memory (
                        id SERIAL PRIMARY KEY,
                        user_id TEXT,
                        query TEXT,
                        answer TEXT,
                        created_at TIMESTAMP
                    )
                    """
                )
            )
 
            await conn.execute(
                text(
                    """
                    INSERT INTO memory (user_id, query, answer, created_at)
                    VALUES (:user_id, :query, :answer, NOW())
                    """
                ),
                {
                    "user_id": user_id,
                    "query": query,
                    "answer": answer,
                },
            )
 
    async def fetch_history(
        self,
        user_id: str,
        limit: int = 5,
    ) -> List[MemoryRecord]:
        """
        Fetch recent interactions.
        """
 
        async with self.engine.connect() as conn:
            result = await conn.execute(
                text(
                    """
                    SELECT user_id, query, answer, created_at
                    FROM memory
                    WHERE user_id = :user_id
                    ORDER BY created_at DESC
                    LIMIT :limit
                    """
                ),
                {"user_id": user_id, "limit": limit},
            )
 
            rows = result.fetchall()
 
        return [
            MemoryRecord(
                user_id=row[0],
                query=row[1],
                answer=row[2],
                created_at=row[3],
            )
            for row in rows
        ]
 