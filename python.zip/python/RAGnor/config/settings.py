"""
Global configuration for Ragnar.
 
- Uses Pydantic v2 BaseSettings
- Loads environment variables from .env
- Central place for all configs (LLM, DB, Vector DB, API)
"""
 
from pydantic_settings import BaseSettings, SettingsConfigDict
from pydantic import Field
from functools import lru_cache
 
 
class Settings(BaseSettings):
    """
    Application settings loaded from .env
    """
 
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )
 
    # =========================
    # APP CONFIG
    # =========================
    APP_NAME: str = "Ragnar"
    ENV: str = Field(default="development")
 
    # =========================
    # OLLAMA CONFIG
    # =========================
    OLLAMA_BASE_URL: str = Field(
        default="http://localhost:11434",
        description="Ollama server URL",
    )
 
    OLLAMA_LLM_MODEL: str = Field(
        default="llama3",
        description="LLM model name in Ollama",
    )
 
    OLLAMA_EMBED_MODEL: str = Field(
        default="nomic-embed-text",
        description="Embedding model in Ollama",
    )
 
    # =========================
    # VECTOR DB (CHROMA DEV)
    # =========================
    CHROMA_PERSIST_DIR: str = Field(
        default="./chroma_db",
        description="Local Chroma DB path",
    )
 
    COLLECTION_NAME: str = Field(
        default="ragnar_docs",
        description="Vector collection name",
    )
 
    # =========================
    # PINECONE (PROD)
    # =========================
    PINECONE_API_KEY: str | None = None
    PINECONE_ENVIRONMENT: str | None = None
    PINECONE_INDEX_NAME: str = "ragnar-index"
 
    # =========================
    # POSTGRES MEMORY
    # =========================
    POSTGRES_URI: str = Field(
        default="postgresql+psycopg://user:password@localhost:5432/ragnar",
        description="Postgres connection string",
    )
 
    # =========================
    # RETRIEVAL CONFIG
    # =========================
    TOP_K: int = 5
    BM25_K: int = 5
    RERANK_TOP_N: int = 3
 
    # =========================
    # LANGSMITH (OBSERVABILITY)
    # =========================
    LANGCHAIN_TRACING_V2: bool = True
    LANGCHAIN_API_KEY: str | None = None
    LANGCHAIN_PROJECT: str = "ragnar"
 
    # =========================
    # API CONFIG
    # =========================
    API_HOST: str = "0.0.0.0"
    API_PORT: int = 8000
 
    # =========================
    # DEBUG
    # =========================
    DEBUG: bool = True
 
 
@lru_cache
def get_settings() -> Settings:
    """
    Cached settings instance to avoid reloading .env multiple times.
    """
    return Settings()
 