"""
Centralized logging configuration.
 
- Structured logging
- Works well with LangSmith tracing
"""
 
import logging
import sys
 
 
def setup_logging() -> None:
    """
    Configure global logging format and level.
    """
 
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
        handlers=[logging.StreamHandler(sys.stdout)],
    )
 
    # Reduce noise from libraries
    logging.getLogger("urllib3").setLevel(logging.WARNING)
    logging.getLogger("httpx").setLevel(logging.WARNING)
 