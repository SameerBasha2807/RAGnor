"""
RAGAS evaluation pipeline.
"""
 
import asyncio
from typing import List, Dict
 
from ragas import evaluate
from ragas.metrics import (
    faithfulness,
    answer_relevancy,
    context_precision,
    context_recall,
)
from datasets import Dataset
 
from ragnar.retrieval.pipeline import RetrievalPipeline
from ragnar.agents.graph import build_graph
from ragnar.agents.state import RagnarState
 
 
class RagasEvaluator:
    """
    Runs RAGAS evaluation on Ragnar.
    """
 
    def __init__(self) -> None:
        self.retriever = RetrievalPipeline()
        self.graph = build_graph()
 
    async def run_query(self, question: str) -> Dict:
        """
        Run full pipeline for one query.
        """
 
        # Retrieve context
        docs = await self.retriever.retrieve(question)
        contexts = [d.page_content for d in docs]
 
        # Run agent
        state: RagnarState = {
            "query": question,
            "rewritten_query": None,
            "documents": docs,
            "answer": None,
            "retrieval_ok": True,
            "answer_ok": True,
            "retries": 0,
        }
 
        async for event in self.graph.astream(state):
            if "answer" in event:
                answer = event["answer"]
 
        return {
            "question": question,
            "answer": answer,
            "contexts": contexts,
        }
 
    async def evaluate(self, dataset: List[Dict]) -> None:
        """
        Run RAGAS evaluation.
        """
 
        results = []
 
        for sample in dataset:
            result = await self.run_query(sample["question"])
            result["ground_truth"] = sample["ground_truth"]
            results.append(result)
 
        # Convert to HuggingFace dataset
        hf_dataset = Dataset.from_list(results)
 
        # Run RAGAS
        scores = evaluate(
            hf_dataset,
            metrics=[
                faithfulness,
                answer_relevancy,
                context_precision,
                context_recall,
            ],
        )
 
        print("\n📊 RAGAS Evaluation Results:")
        print(scores)
 