"""
Build evaluation dataset for RAGAS.
"""
 
from typing import List, Dict
 
 
def build_dataset() -> List[Dict]:
    """
    Create evaluation dataset.
 
    Returns:
        List of QA samples
    """
 
    # You can replace this with real production logs later
    return [
        {
            "question": "What is Ragnar?",
            "ground_truth": "Ragnar is an agentic RAG system built using LangChain and LangGraph.",
        },
        {
            "question": "How does hybrid search work?",
            "ground_truth": "Hybrid search combines BM25 sparse retrieval and dense vector retrieval.",
        },
    ]
 