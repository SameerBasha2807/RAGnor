"""
LangSmith configuration for tracing.
"""
 
import os
from ragnar.config.settings import get_settings
 
 
def setup_langsmith() -> None:
    """
    Enable LangSmith tracing globally.
    """
 
    settings = get_settings()
 
    if settings.LANGCHAIN_API_KEY:
        os.environ["LANGCHAIN_TRACING_V2"] = "true"
        os.environ["LANGCHAIN_API_KEY"] = settings.LANGCHAIN_API_KEY
        os.environ["LANGCHAIN_PROJECT"] = settings.LANGCHAIN_PROJECT
    else:
        # Disable if no key
        os.environ["LANGCHAIN_TRACING_V2"] = "false"
 