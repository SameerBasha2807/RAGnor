"""
Evaluation runner script.
"""
 
import asyncio
 
from ragnar.evaluation.dataset import build_dataset
from ragnar.evaluation.ragas_eval import RagasEvaluator
from ragnar.evaluation.langsmith import setup_langsmith
 
 
async def main() -> None:
    """
    Run full evaluation pipeline.
    """
 
    # Enable tracing
    setup_langsmith()
 
    dataset = build_dataset()
 
    evaluator = RagasEvaluator()
 
    await evaluator.evaluate(dataset)
 
 
if __name__ == "__main__":
    asyncio.run(main())
 